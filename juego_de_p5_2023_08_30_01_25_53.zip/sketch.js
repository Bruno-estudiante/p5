var gameState = "start"
var score = 0;

function preload(){
  willyImg = loadImage("willyRight.png")
  willyImg2 = loadImage("willyLeft.png")
  badImg = loadImage("badthing.png")
  goodImg = loadImage("goodthing.png")
  baseImg = loadImage("grayblock.png")
  }
function setup() {
  createCanvas(600, 450);
  player = createSprite(230, 400, 20, 20)
  player.addImage(willyImg)
  player.scale = 0.08
  basegroup = new Group();
  badgroup = new Group();
  goodgroup = new Group();
  }

function draw() {
  background("darkblue");
  
  if (gameState == "start"){
    
    gameState = "play"
    }
  
  if (gameState == "play"){
    if (keyDown("right")){
    player.x = player.x +30
}
if(player.isTouching(goodgroup, removegoodthings)){
      score += 1
    }
if (keyDown("left")){
    player.x = player.x -30
 } 
crearBases();
badThings();
goodThings();
    }
  
  if (gameState == "gameOVER"){
    
    }
  
  
drawSprites();
  textSize(25);
  fill("white")
  text("puntuacion: " + score, 50, 50)
}

function crearBases(){
if (frameCount%70==0){
  base = createSprite(random(20, 580), 0, 25, 25)
  base.velocityY = 2;
  base.addImage(baseImg)
  base.scale = 0.05;
  }
  }

function badThings(){
  var velo = 3;
  if (frameCount%50==0){
    bad = createSprite(random(20, 580), 0, 25, 25)
    bad.velocityY = 2;
    bad.addImage(badImg)
    bad.scale = 0.17;
    badgroup.add(bad);
  }
}

function goodThings(){
  var velo = 3;
  if (frameCount%80==0){
    good = createSprite(random(20, 580), 0, 25, 25)
    good.velocityY = 2;
    good.addImage(goodImg)
    good.scale = 0.17;
    goodgroup.add(good);
  }
}

function removegoodthings(sprite, goodThing){
  goodThing.remove();
  }